package dao;

import conexion.ConexionDB;
import modelo.Pago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PagoDAO {

    public boolean registrarPago(Pago pago) {
        try {
            double total = totalOrden(pago.getIdOrden());
            double pagado = totalPagado(pago.getIdOrden());
            double saldo = total - pagado;

    if (pago.getMonto() <= 0 || total <= 0 || saldo <= 0) {
                return false; }

 String tipo = pago.getTipoPago();

  if (tipo.equalsIgnoreCase("Completo") && Math.abs(pago.getMonto() - saldo) > 0.01) {
                return false;
            }

    if (pago.getMonto() > saldo) {
                return false;
            }

    if (tipo.equalsIgnoreCase("Abono")
                    && pago.getMonto() >= saldo) {
        return false;
        
            }

            String sql = "INSERT INTO Pago VALUES (?, ?, ?, ?, ?)";

            Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, pago.getIdPago());
            ps.setDate(2, pago.getFecha());
            ps.setDouble(3, pago.getMonto());
            ps.setString(4, tipo);
            ps.setInt(5, pago.getIdOrden());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    public double totalPagado(int idOrden) {
        double total = 0;

        try {
            
            
       Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT SUM(monto) FROM Pago WHERE id_orden = ?");

            ps.setInt(1, idOrden);
            ResultSet rs = ps.executeQuery();

   if (rs.next()) {
                total = rs.getDouble(1);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return total;
    }

    public double totalOrden(int idOrden) {
        double total = 0;

        try {
            Connection con = ConexionDB.getConnection();

            String sql = "SELECT SUM(s.costo_mano_obra) " + "FROM DetalleServicio d "
                    + "INNER JOIN Servicio s ON d.id_servicio = s.id_servicio "
                    + "WHERE d.id_orden = ?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idOrden);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                total = rs.getDouble(1);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return total;
    }
}