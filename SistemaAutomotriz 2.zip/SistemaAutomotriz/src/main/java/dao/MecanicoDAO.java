package dao;
import modelo.Mecanico;
import conexion.ConexionDB;
import java.sql.*;
import java.util.ArrayList;

public class MecanicoDAO {

    private Mecanico armarMecanico(ResultSet rs) throws SQLException {
        Mecanico mec = new Mecanico();
        mec.setIdMecanico(rs.getInt("id_mecanico"));
        mec.setNombre(rs.getString("nombre"));
        mec.setEspecialidad(rs.getString("especialidad"));
        mec.setIdOrden(rs.getInt("id_orden"));  
        return mec;
    }

    public ArrayList<Mecanico> listar(){
        ArrayList<Mecanico> lista = new ArrayList<>();
        String sql = "SELECT id_mecanico, nombre, especialidad, id_orden FROM Mecanico ORDER BY id_mecanico";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(armarMecanico(rs));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<Mecanico> buscar(String texto){
        ArrayList<Mecanico> lista = new ArrayList<>();
        String sql = "SELECT id_mecanico, nombre, especialidad, id_orden FROM Mecanico "
                + "WHERE nombre LIKE ? OR especialidad LIKE ? ORDER BY id_mecanico";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){
                    lista.add(armarMecanico(rs));
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    private int siguienteId(Connection con) throws SQLException {
        String sql = "SELECT ISNULL(MAX(id_mecanico), 0) + 1 FROM Mecanico";
        try(PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            if(rs.next()){
                return rs.getInt(1);
            }
        }
        return 1;
    }

    public boolean insertar(Mecanico mec){
        String sql = "INSERT INTO Mecanico (id_mecanico, nombre, especialidad) VALUES (?, ?, ?)";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, siguienteId(con));
            ps.setString(2, mec.getNombre());
            ps.setString(3, mec.getEspecialidad());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean modificar(Mecanico mec){
        String sql = "UPDATE Mecanico SET nombre = ?, especialidad = ? WHERE id_mecanico = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, mec.getNombre());
            ps.setString(2, mec.getEspecialidad());
            ps.setInt(3, mec.getIdMecanico());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean eliminar(int idMecanico){
        String sql = "DELETE FROM Mecanico WHERE id_mecanico = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, idMecanico);

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

}
