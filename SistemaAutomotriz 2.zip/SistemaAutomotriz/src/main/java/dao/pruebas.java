package dao;

import modelo.Repuesto;

public class pruebas {

public static void main(String[] args) {

    InventarioDAO dao = new InventarioDAO();

    if (dao.registrarSalida(7, 3)) {
        System.out.println("Salida registrada correctamente");
    } else {
        System.out.println("Error al registrar salida");
    }
}
}