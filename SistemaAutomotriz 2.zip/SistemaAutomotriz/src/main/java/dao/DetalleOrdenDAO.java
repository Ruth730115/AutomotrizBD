package dao;

import conexion.ConexionDB;
import modelo.DetalleOrden;
import java.sql.*;

public class DetalleOrdenDAO {

    public boolean registrar(DetalleOrden d) {
        try {
            Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO DetalleServicio VALUES (?, ?, ?)");

            ps.setInt(1, d.getIdDetalle());
            ps.setInt(2, d.getIdOrden());
            ps.setInt(3, d.getIdServicio());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}