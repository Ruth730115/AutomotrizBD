package dao;
import modelo.Servicio;
import conexion.ConexionDB;
import java.sql.*;
import java.util.ArrayList;

public class ServicioDAO {

    private Servicio armarServicio(ResultSet rs) throws SQLException {
        Servicio ser = new Servicio();
        ser.setIdServicio(rs.getInt("id_servicio"));
        ser.setCodigo(rs.getString("codigo"));
        ser.setNombre(rs.getString("nombre"));
        ser.setDescripcion(rs.getString("descripcion"));
        ser.setNivel(rs.getInt("nivel"));
        ser.setCostoManoObra(rs.getDouble("costo_mano_obra"));
        ser.setTiempoEstimado(rs.getDouble("tiempo_estimado"));
        return ser;
    }
    public ArrayList<Servicio> listar(){
        ArrayList<Servicio> lista = new ArrayList<>();
        String sql = "SELECT id_servicio, codigo, nombre, descripcion, nivel, costo_mano_obra, tiempo_estimado "
                + "FROM Servicio ORDER BY nivel, codigo";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(armarServicio(rs));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<Servicio> buscar(String texto){
        ArrayList<Servicio> lista = new ArrayList<>();
        String sql = "SELECT id_servicio, codigo, nombre, descripcion, nivel, costo_mano_obra, tiempo_estimado "
                + "FROM Servicio WHERE codigo LIKE ? OR nombre LIKE ? OR descripcion LIKE ? ORDER BY nivel, codigo";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");
            ps.setString(3, "%" + texto + "%");
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){
                    lista.add(armarServicio(rs));
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public boolean existeCodigo(String codigo, int idServicio){
        String sql = "SELECT COUNT(*) FROM Servicio WHERE codigo = ? AND id_servicio <> ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, codigo);
            ps.setInt(2, idServicio);
            try(ResultSet rs = ps.executeQuery()){
                if(rs.next()){
                    return rs.getInt(1) > 0;
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    private int siguienteId(Connection con) throws SQLException {
        String sql = "SELECT ISNULL(MAX(id_servicio), 0) + 1 FROM Servicio";
        try(PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            if(rs.next()){
                return rs.getInt(1);
            }
        }
        return 1;
    }

    public boolean insertar(Servicio ser){
        String sql = "INSERT INTO Servicio (id_servicio, codigo, nombre, descripcion, nivel, costo_mano_obra, tiempo_estimado) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, siguienteId(con));
            ps.setString(2, ser.getCodigo());
            ps.setString(3, ser.getNombre());
            ps.setString(4, ser.getDescripcion());
            ps.setInt(5, ser.getNivel());
            ps.setDouble(6, ser.getCostoManoObra());
            ps.setDouble(7, ser.getTiempoEstimado());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean modificar(Servicio ser){
        String sql = "UPDATE Servicio SET codigo = ?, nombre = ?, descripcion = ?, nivel = ?, "
                + "costo_mano_obra = ?, tiempo_estimado = ? WHERE id_servicio = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, ser.getCodigo());
            ps.setString(2, ser.getNombre());
            ps.setString(3, ser.getDescripcion());
            ps.setInt(4, ser.getNivel());
            ps.setDouble(5, ser.getCostoManoObra());
            ps.setDouble(6, ser.getTiempoEstimado());
            ps.setInt(7, ser.getIdServicio());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean eliminar(int idServicio){
        String sql = "DELETE FROM Servicio WHERE id_servicio = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, idServicio);

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

}
