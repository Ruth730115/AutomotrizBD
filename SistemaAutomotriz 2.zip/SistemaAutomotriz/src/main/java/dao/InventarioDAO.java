
package dao;

import conexion.ConexionDB;
import modelo.Repuesto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventarioDAO {

    public boolean registrarRepuesto(Repuesto r) {
        String sql = "INSERT INTO Repuesto VALUES (?, ?, ?, ?, ?)";

        try {
            Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, r.getIdRepuesto());
            ps.setString(2, r.getNombre());
            ps.setInt(3, r.getStock());
            ps.setDouble(4, r.getPrecio());
            ps.setInt(5, r.getIdProveedor());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public List<Repuesto> listarRepuestos() {
        List<Repuesto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Repuesto";

        try {
            Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new Repuesto(
                    rs.getInt("id_repuesto"),
                    rs.getString("nombre"),
                    rs.getInt("stock"),
                    rs.getDouble("precio"),
                    rs.getInt("id_proveedor")
                ));
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return lista;
    }

    public boolean registrarEntrada(int id, int cantidad) {
        return movimiento(id, cantidad, "ENTRADA");
    }

    public boolean registrarSalida(int id, int cantidad) {
        return movimiento(id, cantidad, "SALIDA");
    }

    private boolean movimiento(int id, int cantidad, String tipo) {
        if (cantidad <= 0) return false;

        Connection con = null;

        try {
            con = ConexionDB.getConnection();
            con.setAutoCommit(false);

            String sql;

            if (tipo.equals("ENTRADA")) {
                sql = "UPDATE Repuesto SET stock = stock + ? WHERE id_repuesto = ?";
            } else {
                sql = "UPDATE Repuesto SET stock = stock - ? WHERE id_repuesto = ? AND stock >= ?";
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, cantidad);
            ps.setInt(2, id);

            if (tipo.equals("SALIDA")) {
                ps.setInt(3, cantidad);
            }

            if (ps.executeUpdate() == 0) {
                con.rollback();
                return false;
            }

            PreparedStatement pm = con.prepareStatement(
                "INSERT INTO MovimientoInventario "
                + "(id_movimiento, tipo, cantidad, fecha, id_repuesto) "
                + "VALUES ((SELECT ISNULL(MAX(id_movimiento),0)+1 "
                + "FROM MovimientoInventario), ?, ?, GETDATE(), ?)");

            pm.setString(1, tipo);
            pm.setInt(2, cantidad);
            pm.setInt(3, id);
            pm.executeUpdate();

            con.commit();
            return true;

        } catch (Exception e) {
            try {
                if (con != null) con.rollback();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }

            System.out.println("Error: " + e.getMessage());
            return false;

        } finally {
            try {
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public List<Repuesto> stockMinimo() {
        List<Repuesto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Repuesto WHERE stock <= 5";

        try {
            Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new Repuesto(
                    rs.getInt("id_repuesto"),
                    rs.getString("nombre"),
                    rs.getInt("stock"),
                    rs.getDouble("precio"),
                    rs.getInt("id_proveedor")
                ));
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return lista;
    }
    public boolean actualizarRepuesto(Repuesto r) {
    String sql = "UPDATE Repuesto SET nombre=?, stock=?, precio=?, id_proveedor=? "
               + "WHERE id_repuesto=?";

    try {
        Connection con = ConexionDB.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, r.getNombre());
        ps.setInt(2, r.getStock());
        ps.setDouble(3, r.getPrecio());
        ps.setInt(4, r.getIdProveedor());
        ps.setInt(5, r.getIdRepuesto());

        return ps.executeUpdate() > 0;

    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
        return false;
    }
}
    
    public boolean eliminarRepuesto(int id) {
    String sql = "DELETE FROM Repuesto WHERE id_repuesto=?";

    try {
        Connection con = ConexionDB.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, id);

        return ps.executeUpdate() > 0;

    } catch (Exception e) {
        System.out.println(e.getMessage());
        return false;
    }
}
    
    
    public Repuesto buscarPorId(int id) {
    String sql = "SELECT * FROM Repuesto WHERE id_repuesto = ?";

    try {
        Connection con = ConexionDB.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return new Repuesto(
                rs.getInt("id_repuesto"),
                rs.getString("nombre"),
                rs.getInt("stock"),
                rs.getDouble("precio"),
                rs.getInt("id_proveedor")
            );
        }

    } catch (Exception e) {
        System.out.println("Error al buscar: " + e.getMessage());
    }

    return null;
}
}
