package dao;
import modelo.Cliente;
import conexion.ConexionDB;
import java.sql.*;
import java.util.ArrayList;

public class ClienteDAO {

    private Cliente armarCliente(ResultSet rs) throws SQLException {
        Cliente cli = new Cliente();
        cli.setIdCliente(rs.getInt("id_cliente"));
        cli.setNombre(rs.getString("nombre"));
        cli.setTelefono(rs.getString("telefono"));
        cli.setCorreo(rs.getString("correo"));
        cli.setActivo(rs.getBoolean("activo"));
        return cli;
    }

    public ArrayList<Cliente> listar(){
        ArrayList<Cliente> lista = new ArrayList<>();
        String sql = "SELECT id_cliente, nombre, telefono, correo, activo FROM Cliente ORDER BY id_cliente";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(armarCliente(rs));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<Cliente> buscar(String texto){
        ArrayList<Cliente> lista = new ArrayList<>();
        String sql = "SELECT id_cliente, nombre, telefono, correo, activo FROM Cliente "
                + "WHERE nombre LIKE ? OR telefono LIKE ? OR correo LIKE ? ORDER BY id_cliente";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");
            ps.setString(3, "%" + texto + "%");
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){
                    lista.add(armarCliente(rs));
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    private int siguienteId(Connection con) throws SQLException {
        String sql = "SELECT ISNULL(MAX(id_cliente), 0) + 1 FROM Cliente";
        try(PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            if(rs.next()){
                return rs.getInt(1);
            }
        }
        return 1;
    }

    public boolean insertar(Cliente cli){
        String sql = "INSERT INTO Cliente (id_cliente, nombre, telefono, correo, activo) VALUES (?, ?, ?, ?, 1)";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, siguienteId(con));
            ps.setString(2, cli.getNombre());
            ps.setString(3, cli.getTelefono());
            ps.setString(4, cli.getCorreo());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean modificar(Cliente cli){
        String sql = "UPDATE Cliente SET nombre = ?, telefono = ?, correo = ? WHERE id_cliente = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, cli.getNombre());
            ps.setString(2, cli.getTelefono());
            ps.setString(3, cli.getCorreo());
            ps.setInt(4, cli.getIdCliente());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean desactivar(int idCliente){
        return cambiarEstado(idCliente, 0);
    }

    public boolean activar(int idCliente){
        return cambiarEstado(idCliente, 1);
    }

    private boolean cambiarEstado(int idCliente, int estado){
        String sql = "UPDATE Cliente SET activo = ? WHERE id_cliente = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, estado);
            ps.setInt(2, idCliente);

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }
}
