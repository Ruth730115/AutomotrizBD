
package dao;

import conexion.ConexionDB;
import modelo.Pago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PagoDAO {

    public boolean registrarPago(Pago pago, double totalPagar) {

        Connection con = null;

        try {
            con = ConexionDB.getConnection();

            con.setAutoCommit(false);
            con.setTransactionIsolation(
                    Connection.TRANSACTION_SERIALIZABLE
            );

            // Consultar cuánto se ha pagado de la orden
            double pagado = 0;

            String sqlPagado =
                    "SELECT ISNULL(SUM(monto), 0) "
                    + "FROM Pago WHERE id_orden = ?";

            try (PreparedStatement ps = con.prepareStatement(sqlPagado)) {

                ps.setInt(1, pago.getIdOrden());

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        pagado = rs.getDouble(1);
                    }
                }
            }

            // Calcular saldo pendiente
            double saldo = totalPagar - pagado;
            double ingreso = pago.getMonto();

            String tipo = pago.getTipoPago();

            if (ingreso <= 0 || totalPagar <= 0 || saldo <= 0) {
                con.rollback();
                return false;
            }

            if (ingreso > saldo) {
                con.rollback();
                return false;
            }

            // Validar pago completo
            if (tipo.equalsIgnoreCase("Completo")
                    && Math.abs(ingreso - saldo) > 0.01) {

                con.rollback();
                return false;
            }

            // Validar abono
            if (tipo.equalsIgnoreCase("Abono")
                    && ingreso >= saldo) {

                con.rollback();
                return false;
            }

            // Generar ID automáticamente
            int idPago = 1;

            String sqlId =
                    "SELECT ISNULL(MAX(id_pago), 0) + 1 "
                    + "FROM Pago WITH (UPDLOCK, HOLDLOCK)";

            try (PreparedStatement ps = con.prepareStatement(sqlId);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    idPago = rs.getInt(1);
                }
            }

            // Insertar pago
            String sqlInsert =
                    "INSERT INTO Pago "
                    + "(id_pago, fecha, monto, tipo_pago, id_orden) "
                    + "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(sqlInsert)) {

                ps.setInt(1, idPago);
                ps.setDate(2, pago.getFecha());
                ps.setDouble(3, ingreso);
                ps.setString(4, tipo);
                ps.setInt(5, pago.getIdOrden());

                ps.executeUpdate();
            }

            con.commit();
            return true;

        } catch (Exception e) {

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                System.out.println("Error en rollback: " + ex.getMessage());
            }

            System.out.println(
                    "Error al registrar pago: " + e.getMessage()
            );

            return false;

        } finally {

            try {
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println(
                        "Error al cerrar conexión: " + e.getMessage()
                );
            }
        }
    }

    // Consultar total pagado
    public double totalPagado(int idOrden) {

        double total = 0;

        String sql =
                "SELECT ISNULL(SUM(monto), 0) "
                + "FROM Pago WHERE id_orden = ?";

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idOrden);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getDouble(1);
                }
            }

        } catch (Exception e) {
            System.out.println(
                    "Error al consultar pagos: " + e.getMessage()
            );
        }

        return total;
    }

    // Calcular total de servicios de la orden
    public double totalOrden(int idOrden) {

        double total = 0;

        String sql =
                "SELECT ISNULL(SUM(s.costo_mano_obra), 0) "
                + "FROM DetalleServicio d "
                + "INNER JOIN Servicio s "
                + "ON d.id_servicio = s.id_servicio "
                + "WHERE d.id_orden = ?";

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idOrden);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getDouble(1);
                }
            }

        } catch (Exception e) {
            System.out.println(
                    "Error al calcular orden: " + e.getMessage()
            );
        }

        return total;
    }
}
