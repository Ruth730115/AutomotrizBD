package dao;

import conexion.ConexionDB;
import modelo.OrdenTrabajo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrdenTrabajoDAO {

    public boolean registrarOrden(OrdenTrabajo orden) {

        String sql = "INSERT INTO OrdenTrabajo "
                + "(id_orden, fecha, diagnostico, estado, id_vehiculo) "
                + "VALUES (?, ?, ?, ?, ?)";

        try {
            Connection con = ConexionDB.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, orden.getIdOrden());
            ps.setDate(2, orden.getFecha());
            ps.setString(3, orden.getDiagnostico());
            ps.setString(4, orden.getEstado());
            ps.setInt(5, orden.getIdVehiculo());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }
    public boolean cambiarEstado(int idOrden, String estado) {
    try {
        Connection con = ConexionDB.getConnection();

        String sql = "UPDATE OrdenTrabajo SET estado = ? WHERE id_orden = ?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, estado);
        ps.setInt(2, idOrden);

        return ps.executeUpdate() > 0;

    } catch (Exception e) {
        System.out.println(e.getMessage());
        return false;
    }
}
    public boolean asignarMecanico(int idMecanico, int idOrden) {
    try {
        Connection con = ConexionDB.getConnection();

        String sql = "UPDATE Mecanico SET id_orden = ? WHERE id_mecanico = ?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, idOrden);
        ps.setInt(2, idMecanico);

        return ps.executeUpdate() > 0;

    } catch (Exception e) {
        System.out.println(e.getMessage());
        return false;
    }
}
    public java.util.List<OrdenTrabajo> listarOrdenes() {
    java.util.List<OrdenTrabajo> lista = new java.util.ArrayList<>();

    String sql = "SELECT id_orden, fecha, diagnostico, estado, id_vehiculo "
               + "FROM OrdenTrabajo";

    try {
        Connection con = ConexionDB.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            OrdenTrabajo orden = new OrdenTrabajo(
                rs.getInt("id_orden"),
                rs.getDate("fecha"),
                rs.getString("diagnostico"),
                rs.getString("estado"),
                rs.getInt("id_vehiculo")
            );

            lista.add(orden);
        }

    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }

    return lista;
}
}