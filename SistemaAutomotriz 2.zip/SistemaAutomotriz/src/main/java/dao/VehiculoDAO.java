package dao;
import modelo.Vehiculo;
import conexion.ConexionDB;
import java.sql.*;
import java.util.ArrayList;

public class VehiculoDAO {

    private Vehiculo armarVehiculo(ResultSet rs) throws SQLException {
        Vehiculo veh = new Vehiculo();
        veh.setIdVehiculo(rs.getInt("id_vehiculo"));
        veh.setPlaca(rs.getString("placa"));
        veh.setMarca(rs.getString("marca"));
        veh.setModelo(rs.getString("modelo"));
        java.sql.Date fecha = rs.getDate("año");
        if(fecha != null){
            veh.setAnio(fecha.toLocalDate().getYear());
        }
        veh.setIdCliente(rs.getInt("id_cliente"));
        return veh;
    }

    public ArrayList<Vehiculo> listar(){
        ArrayList<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT id_vehiculo, placa, marca, modelo, [año], id_cliente FROM Vehiculo ORDER BY id_vehiculo";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(armarVehiculo(rs));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<Vehiculo> buscar(String texto){
        ArrayList<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT v.id_vehiculo, v.placa, v.marca, v.modelo, v.[año], v.id_cliente "
                + "FROM Vehiculo v INNER JOIN Cliente c ON v.id_cliente = c.id_cliente "
                + "WHERE v.placa LIKE ? OR v.marca LIKE ? OR v.modelo LIKE ? OR c.nombre LIKE ? "
                + "ORDER BY v.id_vehiculo";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");
            ps.setString(3, "%" + texto + "%");
            ps.setString(4, "%" + texto + "%");
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){
                    lista.add(armarVehiculo(rs));
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public boolean existePlaca(String placa, int idVehiculo){
        String sql = "SELECT COUNT(*) FROM Vehiculo WHERE placa = ? AND id_vehiculo <> ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, placa);
            ps.setInt(2, idVehiculo);
            try(ResultSet rs = ps.executeQuery()){
                if(rs.next()){
                    return rs.getInt(1) > 0;
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    private int siguienteId(Connection con) throws SQLException {
        String sql = "SELECT ISNULL(MAX(id_vehiculo), 0) + 1 FROM Vehiculo";
        try(PreparedStatement ps = con.prepareStatement(sql);
               ResultSet rs = ps.executeQuery()){
            if(rs.next()){
                return rs.getInt(1);
            }
        }
        return 1;
    }

    public boolean insertar(Vehiculo veh){
        String sql = "INSERT INTO Vehiculo (id_vehiculo, placa, marca, modelo, [año], id_cliente) VALUES (?, ?, ?, ?, ?, ?)";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, siguienteId(con));
            ps.setString(2, veh.getPlaca());
            ps.setString(3, veh.getMarca());
            ps.setString(4, veh.getModelo());
            ps.setDate(5, java.sql.Date.valueOf(veh.getAnio() + "-01-01"));
            ps.setInt(6, veh.getIdCliente());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean modificar(Vehiculo veh){
        String sql = "UPDATE Vehiculo SET placa = ?, marca = ?, modelo = ?, [año] = ?, id_cliente = ? WHERE id_vehiculo = ?";
        try(Connection con = ConexionDB.getConexion();
               PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, veh.getPlaca());
            ps.setString(2, veh.getMarca());
            ps.setString(3, veh.getModelo());
            ps.setDate(4, java.sql.Date.valueOf(veh.getAnio() + "-01-01"));
            ps.setInt(5, veh.getIdCliente());
            ps.setInt(6, veh.getIdVehiculo());

            int filas = ps.executeUpdate();
            if(filas > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }

}
