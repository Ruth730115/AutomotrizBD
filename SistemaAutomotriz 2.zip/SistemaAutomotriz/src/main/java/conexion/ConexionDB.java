package conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author caria
 */
public class ConexionDB {

    private static final String URL = "jdbc:sqlserver://localhost:1433;"
            + "databaseName=AutomotrizDB;"
            + "encrypt=true;"
            + "trustServerCertificate=true;";

    private static final String USER = "sa";
    private static final String PASS = "Banco2026!SQL";

    private static Connection connection = null;

    private ConexionDB() {
    }

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                connection = DriverManager.getConnection(URL, USER, PASS);
                System.out.println("-> Conexion Exitosa a SQL");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Error: no se encontro el driver mssql-jdbc -> " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Error al conectar con SQL -> " + e.getMessage());
        }
        return connection;
    }

    public static Connection getConexion() {
        return getConnection();
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                connection = null;
                System.out.println("-> La conexion con SQL esta cerrada");
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexion -> " + e.getMessage());
        }
    }

    public static void cerrarConexion() {
        closeConnection();
    }
    public static void main(String[] args) {
        Connection con = ConexionDB.getConnection();
        if (con != null) {
            System.out.println("Prueba de conexion OK");
            ConexionDB.closeConnection();
        } else {
            System.out.println("No se pudo establecer la conexion");
        }
    }

}
