package modelo;

public class Repuesto {

    private int idRepuesto;
    private String nombre;
    private int stock;
    private double precio;
    private int idProveedor;

    public Repuesto() {
    }

    public Repuesto(int idRepuesto, String nombre, int stock,
                    double precio, int idProveedor) {
        this.idRepuesto = idRepuesto;
        this.nombre = nombre;
        this.stock = stock;
        this.precio = precio;
        this.idProveedor = idProveedor;
    }

    public int getIdRepuesto() {
        return idRepuesto;
    }

    public void setIdRepuesto(int idRepuesto) {
        this.idRepuesto = idRepuesto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }
}