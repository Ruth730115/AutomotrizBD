package modelo;

public class Cliente {
    private int idCliente;
    private String nombre;
    private String telefono;
    private String correo;
    private boolean activo;

    public Cliente(){}

    public Cliente(int idCliente, String nombre, String telefono, String correo, boolean activo){
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.activo = activo;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString(){
        if(activo){
            return idCliente + " - " + nombre;
        }
        return idCliente + " - " + nombre + " (Inactivo)";
    }

}
