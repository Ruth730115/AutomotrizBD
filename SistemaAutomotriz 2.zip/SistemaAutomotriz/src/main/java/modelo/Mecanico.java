package modelo;

public class Mecanico {
    private int idMecanico;
    private String nombre;
    private String especialidad;
    private int idOrden;   

    public Mecanico(){}

    public Mecanico(int idMecanico, String nombre, String especialidad, int idOrden){
        this.idMecanico = idMecanico;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.idOrden = idOrden;
    }

    public int getIdMecanico() {
        return idMecanico;
    }

    public void setIdMecanico(int idMecanico) {
        this.idMecanico = idMecanico;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    @Override
    public String toString(){
        return idMecanico + " - " + nombre;
    }

}
