package modelo;

import java.sql.Date;

public class OrdenTrabajo {

    private int idOrden;
    private Date fecha;
    private String diagnostico;
    private String estado;
    private int idVehiculo;

    public OrdenTrabajo() {
    }

    public OrdenTrabajo(int idOrden, Date fecha, String diagnostico,
                        String estado, int idVehiculo) {
        this.idOrden = idOrden;
        this.fecha = fecha;
        this.diagnostico = diagnostico;
        this.estado = estado;
        this.idVehiculo = idVehiculo;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }
}