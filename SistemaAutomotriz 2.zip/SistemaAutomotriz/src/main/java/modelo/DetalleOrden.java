package modelo;

public class DetalleOrden {

    private int idDetalle;
    private int idOrden;
    private int idServicio;

    public DetalleOrden() {
    }

    public DetalleOrden(int idDetalle, int idOrden, int idServicio) {
        this.idDetalle = idDetalle;
        this.idOrden = idOrden;
        this.idServicio = idServicio;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(int idServicio) {
        this.idServicio = idServicio;
    }
}