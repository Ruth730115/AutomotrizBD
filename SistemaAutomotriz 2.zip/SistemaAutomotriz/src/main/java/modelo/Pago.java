package modelo;

import java.sql.Date;

public class Pago {

    private int idPago;
    private Date fecha;
    private double monto;
    private String tipoPago;
    private int idOrden;

    public Pago() {
    }

    public Pago(int idPago, Date fecha, double monto,
                String tipoPago, int idOrden) {
        this.idPago = idPago;
        this.fecha = fecha;
        this.monto = monto;
        this.tipoPago = tipoPago;
        this.idOrden = idOrden;
    }

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }
}