package vista;
import dao.ClienteDAO;
import dao.VehiculoDAO;
import modelo.Cliente;
import modelo.Vehiculo;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 * @author caria
 */
public class FrmVehiculo extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmVehiculo.class.getName());

    private VehiculoDAO dao = new VehiculoDAO();

    public FrmVehiculo() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Gestion de Vehiculos");

        cargarPropietarios();
        cargarVehiculos(dao.listar());
    }

    private void cargarPropietarios(){
        try{
            ClienteDAO clienteDao = new ClienteDAO();
            ArrayList<Cliente> lista = clienteDao.listar();

            jcbPropietario.removeAllItems();

            for(Cliente cli : lista){
                jcbPropietario.addItem(cli);
            }
            jcbPropietario.setSelectedIndex(-1);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al cargar Clientes" + e.getMessage());
        }
    }

    private void cargarVehiculos(ArrayList<Vehiculo> lista){
        try{
            jcbVehiculo.removeAllItems();

            for(Vehiculo veh : lista){
                jcbVehiculo.addItem(veh);
            }
            jcbVehiculo.setSelectedIndex(-1);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al cargar Vehiculos" + e.getMessage());
        }
    }

    private void seleccionarVehiculo(int idVehiculo){
        for(int i = 0; i < jcbVehiculo.getItemCount(); i++){
            if(jcbVehiculo.getItemAt(i).getIdVehiculo() == idVehiculo){
                jcbVehiculo.setSelectedIndex(i);
                break;
            }
        }
    }

    private void seleccionarPropietario(int idCliente){
        jcbPropietario.setSelectedIndex(-1);
        for(int i = 0; i < jcbPropietario.getItemCount(); i++){
            if(jcbPropietario.getItemAt(i).getIdCliente() == idCliente){
                jcbPropietario.setSelectedIndex(i);
                break;
            }
        }
    }
    private String obtenerMarca(){
        Object marca = jcbMarca.getEditor().getItem();
        if(marca == null){
            return "";
        }
        return marca.toString().trim().toUpperCase();
    }

    private void mostrarDatosEnCampos(Vehiculo veh){
        if(veh != null){
            txtPlaca.setText(veh.getPlaca());
            jcbMarca.setSelectedItem(veh.getMarca());
            txtModelo.setText(veh.getModelo());
            txtAnio.setText(String.valueOf(veh.getAnio()));
            seleccionarPropietario(veh.getIdCliente());
        }else{
            limpiarCampos();
        }
    }

    private void limpiarCampos(){
        txtPlaca.setText("");
        jcbMarca.setSelectedItem("");
        txtModelo.setText("");
        txtAnio.setText("");
        jcbPropietario.setSelectedIndex(-1);
    }

    //validaciones.-.-
    private boolean validarCampos(){
        if(txtPlaca.getText().trim().equals("") || obtenerMarca().equals("") || txtModelo.getText().trim().equals("")
                || txtAnio.getText().trim().equals("") || jcbPropietario.getSelectedItem() == null){
            JOptionPane.showMessageDialog(this, "Debe llenar todos los campos!!");
            return false;
        }
        if(txtPlaca.getText().trim().length() > 10 || obtenerMarca().length() > 25 || txtModelo.getText().trim().length() > 50){
            JOptionPane.showMessageDialog(this, "La placa admite maximo 10 caracteres, la marca 25 y el modelo 50");
            return false;
        }
        int anio;
        try{
            anio = Integer.parseInt(txtAnio.getText().trim());
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "El año debe ser un numero...");
            return false;
        }
        int anioActual = Calendar.getInstance().get(Calendar.YEAR);
        if(anio < 1950 || anio > anioActual + 1){
            JOptionPane.showMessageDialog(this, "El año debe estar entre 1950 y " + (anioActual + 1));
            return false;
        }
        Cliente propietario = (Cliente) jcbPropietario.getSelectedItem();
        if(!propietario.isActivo()){
            JOptionPane.showMessageDialog(this, "El propietario esta inactivo, elija un cliente activo");
            return false;
        }
        return true;
    }

    // Pasa los datos de la pantalla al objeto Vehiculo
    private void llenarVehiculo(Vehiculo veh){
        Cliente propietario = (Cliente) jcbPropietario.getSelectedItem();
        veh.setPlaca(txtPlaca.getText().trim().toUpperCase());
        veh.setMarca(obtenerMarca());
        veh.setModelo(txtModelo.getText().trim());
        veh.setAnio(Integer.parseInt(txtAnio.getText().trim()));
        veh.setIdCliente(propietario.getIdCliente());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnVerTodos = new javax.swing.JButton();
        lblVehiculo = new javax.swing.JLabel();
        jcbVehiculo = new javax.swing.JComboBox<>();
        lblPlaca = new javax.swing.JLabel();
        txtPlaca = new javax.swing.JTextField();
        lblMarca = new javax.swing.JLabel();
        jcbMarca = new javax.swing.JComboBox<>();
        lblModelo = new javax.swing.JLabel();
        txtModelo = new javax.swing.JTextField();
        lblAnio = new javax.swing.JLabel();
        txtAnio = new javax.swing.JTextField();
        lblPropietario = new javax.swing.JLabel();
        jcbPropietario = new javax.swing.JComboBox<>();
        btnNuevo = new javax.swing.JButton();
        btnRegistrar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(0, 153, 153));
        lblTitulo.setText("GESTION DE VEHICULOS");

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(0, 153, 153));
        lblBuscar.setText("Buscar:");

        btnBuscar.setBackground(new java.awt.Color(204, 255, 255));
        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        btnVerTodos.setBackground(new java.awt.Color(204, 255, 255));
        btnVerTodos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnVerTodos.setForeground(new java.awt.Color(0, 102, 102));
        btnVerTodos.setText("Ver todos");
        btnVerTodos.addActionListener(this::btnVerTodosActionPerformed);

        lblVehiculo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblVehiculo.setForeground(new java.awt.Color(0, 153, 153));
        lblVehiculo.setText("Vehiculo:");

        jcbVehiculo.addActionListener(this::jcbVehiculoActionPerformed);

        lblPlaca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblPlaca.setForeground(new java.awt.Color(0, 153, 153));
        lblPlaca.setText("Placa:");

        lblMarca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblMarca.setForeground(new java.awt.Color(0, 153, 153));
        lblMarca.setText("Marca:");

        jcbMarca.setEditable(true);
        jcbMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TOYOTA", "HONDA", "MAZDA", "NISSAN", "SUZUKI", "SUBARU", "MITSUBISHI", "LEXUS", "ACURA", "INFINITI", "CHEVROLET", "FORD", "JEEP", "RAM", "DODGE", "GMC", "CADILLAC", "LINCOLN", "TESLA", "BUICK", "CHRYSLER", "VOLKSWAGEN", "BMW", "MERCEDES-BENZ", "AUDI", "PORSCHE", "HYUNDAI", "KIA", "GENESIS", "BYD", "MG", "CHERY", "JAC", "GEELY", "GWM", "OMODA", "JETOUR" }));

        lblModelo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblModelo.setForeground(new java.awt.Color(0, 153, 153));
        lblModelo.setText("Modelo:");

        lblAnio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblAnio.setForeground(new java.awt.Color(0, 153, 153));
        lblAnio.setText("Año:");

        lblPropietario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblPropietario.setForeground(new java.awt.Color(0, 153, 153));
        lblPropietario.setText("Propietario:");

        btnNuevo.setBackground(new java.awt.Color(204, 255, 255));
        btnNuevo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 102, 102));
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(this::btnNuevoActionPerformed);

        btnRegistrar.setBackground(new java.awt.Color(204, 255, 255));
        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrar.setForeground(new java.awt.Color(0, 102, 102));
        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(this::btnRegistrarActionPerformed);

        btnModificar.setBackground(new java.awt.Color(204, 255, 255));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnModificar.setForeground(new java.awt.Color(0, 102, 102));
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(this::btnModificarActionPerformed);

        btnSalir.setBackground(new java.awt.Color(204, 255, 255));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 102, 102));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(this::btnSalirActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnVerTodos, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jcbVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jcbMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jcbPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(lblTitulo)
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBuscar)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(btnVerTodos))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblVehiculo)
                    .addComponent(jcbVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPlaca)
                    .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMarca)
                    .addComponent(jcbMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblModelo)
                    .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAnio)
                    .addComponent(txtAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPropietario)
                    .addComponent(jcbPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevo)
                    .addComponent(btnRegistrar)
                    .addComponent(btnModificar)
                    .addComponent(btnSalir))
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jcbVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbVehiculoActionPerformed
        Vehiculo vehSeleccionado = (Vehiculo) jcbVehiculo.getSelectedItem();
        mostrarDatosEnCampos(vehSeleccionado);
    }//GEN-LAST:event_jcbVehiculoActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String texto = txtBuscar.getText().trim();
        if(texto.equals("")){
            JOptionPane.showMessageDialog(this, "Escriba la placa, marca, modelo o nombre del dueño a buscar");
            return;
        }
        ArrayList<Vehiculo> resultado = dao.buscar(texto);
        if(resultado.isEmpty()){
            JOptionPane.showMessageDialog(this, "No se encontraron vehiculos");
            return;
        }
        cargarVehiculos(resultado);
        jcbVehiculo.setSelectedIndex(0);
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnVerTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerTodosActionPerformed
        txtBuscar.setText("");
        cargarPropietarios();
        cargarVehiculos(dao.listar());
    }//GEN-LAST:event_btnVerTodosActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        jcbVehiculo.setSelectedIndex(-1);
        limpiarCampos();
        txtPlaca.requestFocus();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        if(jcbVehiculo.getSelectedItem() != null){
            JOptionPane.showMessageDialog(this, "Presione 'Nuevo' para registrar un vehiculo nuevo o 'Modificar' para cambiar el seleccionado");
            return;
        }
        if(!validarCampos()){
            return;
        }
        Vehiculo veh = new Vehiculo();
        llenarVehiculo(veh);

        if(dao.existePlaca(veh.getPlaca(), 0)){
            JOptionPane.showMessageDialog(this, "Ya existe un vehiculo con esa placa");
            return;
        }
        if(dao.insertar(veh)){
            JOptionPane.showMessageDialog(this, "Vehiculo guardado correctamente!");
            txtBuscar.setText("");
            cargarVehiculos(dao.listar());
            limpiarCampos();
        }else{
            JOptionPane.showMessageDialog(this, "No se pudo guardar el vehiculo");
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        Vehiculo veh = (Vehiculo) jcbVehiculo.getSelectedItem();
        if(veh == null){
            JOptionPane.showMessageDialog(this, "Seleccione un vehiculo del combo");
            return;
        }
        if(!validarCampos()){
            return;
        }
        int id = veh.getIdVehiculo();
        llenarVehiculo(veh);

        if(dao.existePlaca(veh.getPlaca(), id)){
            JOptionPane.showMessageDialog(this, "Ya existe otro vehiculo con esa placa");
            return;
        }
        if(dao.modificar(veh)){
            JOptionPane.showMessageDialog(this, "Vehiculo modificado correctamente!");
        }else{
            JOptionPane.showMessageDialog(this, "No se pudo modificar el vehiculo");
        }
        cargarVehiculos(dao.listar());
        seleccionarVehiculo(id);
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new FrmVehiculo().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnVerTodos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> jcbMarca;
    private javax.swing.JComboBox<modelo.Cliente> jcbPropietario;
    private javax.swing.JComboBox<modelo.Vehiculo> jcbVehiculo;
    private javax.swing.JLabel lblAnio;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblMarca;
    private javax.swing.JLabel lblModelo;
    private javax.swing.JLabel lblPlaca;
    private javax.swing.JLabel lblPropietario;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblVehiculo;
    private javax.swing.JTextField txtAnio;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextField txtPlaca;
    // End of variables declaration//GEN-END:variables
}
