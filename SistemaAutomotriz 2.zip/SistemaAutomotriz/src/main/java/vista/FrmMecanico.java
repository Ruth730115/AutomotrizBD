package vista;
import dao.MecanicoDAO;
import modelo.Mecanico;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * @author caria
 */
public class FrmMecanico extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmMecanico.class.getName());

    private MecanicoDAO dao = new MecanicoDAO();

    public FrmMecanico() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Gestion de Mecanicos");

        cargarMecanicos(dao.listar());
    }

    private void cargarMecanicos(ArrayList<Mecanico> lista){
        try{
            jcbMecanico.removeAllItems();

            for(Mecanico mec : lista){
                jcbMecanico.addItem(mec);
            }
            jcbMecanico.setSelectedIndex(-1);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al cargar Mecanicos" + e.getMessage());
        }
    }

    private void seleccionarMecanico(int idMecanico){
        for(int i = 0; i < jcbMecanico.getItemCount(); i++){
            if(jcbMecanico.getItemAt(i).getIdMecanico() == idMecanico){
                jcbMecanico.setSelectedIndex(i);
                break;
            }
        }
    }

    private void mostrarDatosEnCampos(Mecanico mec){
        if(mec != null){
            txtNombre.setText(mec.getNombre());
            txtEspecialidad.setText(mec.getEspecialidad());
            if(mec.getIdOrden() == 0){
                txtOrden.setText("Sin orden");
            }else{
                txtOrden.setText(String.valueOf(mec.getIdOrden()));
            }
        }else{
            limpiarCampos();
        }
    }

    private void limpiarCampos(){
        txtNombre.setText("");
        txtEspecialidad.setText("");
        txtOrden.setText("");
    }

    // validaciones
    private boolean validarCampos(){
        if(txtNombre.getText().trim().equals("") || txtEspecialidad.getText().trim().equals("")){
            JOptionPane.showMessageDialog(this, "Debe llenar todos los campos!!");
            return false;
        }
        if(txtNombre.getText().trim().length() > 50 || txtEspecialidad.getText().trim().length() > 50){
            JOptionPane.showMessageDialog(this, "El nombre y la especialidad admiten maximo 50 caracteres");
            return false;
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnVerTodos = new javax.swing.JButton();
        lblMecanico = new javax.swing.JLabel();
        jcbMecanico = new javax.swing.JComboBox<>();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblEspecialidad = new javax.swing.JLabel();
        txtEspecialidad = new javax.swing.JTextField();
        lblOrden = new javax.swing.JLabel();
        txtOrden = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnRegistrar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(0, 153, 153));
        lblTitulo.setText("GESTION DE MECANICOS");

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(0, 153, 153));
        lblBuscar.setText("Buscar:");

        btnBuscar.setBackground(new java.awt.Color(204, 255, 255));
        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        btnVerTodos.setBackground(new java.awt.Color(204, 255, 255));
        btnVerTodos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnVerTodos.setForeground(new java.awt.Color(0, 102, 102));
        btnVerTodos.setText("Ver todos");
        btnVerTodos.addActionListener(this::btnVerTodosActionPerformed);

        lblMecanico.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblMecanico.setForeground(new java.awt.Color(0, 153, 153));
        lblMecanico.setText("Mecanico:");

        jcbMecanico.addActionListener(this::jcbMecanicoActionPerformed);

        lblNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNombre.setForeground(new java.awt.Color(0, 153, 153));
        lblNombre.setText("Nombre:");

        lblEspecialidad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblEspecialidad.setForeground(new java.awt.Color(0, 153, 153));
        lblEspecialidad.setText("Especialidad:");

        lblOrden.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblOrden.setForeground(new java.awt.Color(0, 153, 153));
        lblOrden.setText("Orden asignada:");

        txtOrden.setEditable(false);

        btnNuevo.setBackground(new java.awt.Color(204, 255, 255));
        btnNuevo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 102, 102));
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(this::btnNuevoActionPerformed);

        btnRegistrar.setBackground(new java.awt.Color(204, 255, 255));
        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrar.setForeground(new java.awt.Color(0, 102, 102));
        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(this::btnRegistrarActionPerformed);

        btnModificar.setBackground(new java.awt.Color(204, 255, 255));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnModificar.setForeground(new java.awt.Color(0, 102, 102));
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(this::btnModificarActionPerformed);

        btnEliminar.setBackground(new java.awt.Color(204, 255, 255));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(0, 102, 102));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);

        btnSalir.setBackground(new java.awt.Color(204, 255, 255));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 102, 102));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(this::btnSalirActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnVerTodos, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jcbMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblOrden, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtOrden, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(lblTitulo)
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBuscar)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(btnVerTodos))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMecanico)
                    .addComponent(jcbMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEspecialidad)
                    .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblOrden)
                    .addComponent(txtOrden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevo)
                    .addComponent(btnRegistrar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)
                    .addComponent(btnSalir))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jcbMecanicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbMecanicoActionPerformed
        Mecanico mecSeleccionado = (Mecanico) jcbMecanico.getSelectedItem();
        mostrarDatosEnCampos(mecSeleccionado);
    }//GEN-LAST:event_jcbMecanicoActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String texto = txtBuscar.getText().trim();
        if(texto.equals("")){
            JOptionPane.showMessageDialog(this, "Escriba el nombre o la especialidad a buscar");
            return;
        }
        ArrayList<Mecanico> resultado = dao.buscar(texto);
        if(resultado.isEmpty()){
            JOptionPane.showMessageDialog(this, "No se encontraron mecanicos");
            return;
        }
        cargarMecanicos(resultado);
        jcbMecanico.setSelectedIndex(0);
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnVerTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerTodosActionPerformed
        txtBuscar.setText("");
        cargarMecanicos(dao.listar());
    }//GEN-LAST:event_btnVerTodosActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        jcbMecanico.setSelectedIndex(-1);
        limpiarCampos();
        txtNombre.requestFocus();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        if(jcbMecanico.getSelectedItem() != null){
            JOptionPane.showMessageDialog(this, "Presione 'Nuevo' para registrar un mecanico nuevo o 'Modificar' para cambiar el seleccionado");
            return;
        }
        if(!validarCampos()){
            return;
        }
        Mecanico mec = new Mecanico();
        mec.setNombre(txtNombre.getText().trim());
        mec.setEspecialidad(txtEspecialidad.getText().trim());

        if(dao.insertar(mec)){
            JOptionPane.showMessageDialog(this, "Mecanico guardado correctamente!");
            txtBuscar.setText("");
            cargarMecanicos(dao.listar());
            limpiarCampos();
        }else{
            JOptionPane.showMessageDialog(this, "No se pudo guardar el mecanico");
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        Mecanico mec = (Mecanico) jcbMecanico.getSelectedItem();
        if(mec == null){
            JOptionPane.showMessageDialog(this, "Seleccione un mecanico del combo");
            return;
        }
        if(!validarCampos()){
            return;
        }
        mec.setNombre(txtNombre.getText().trim());
        mec.setEspecialidad(txtEspecialidad.getText().trim());

        if(dao.modificar(mec)){
            JOptionPane.showMessageDialog(this, "Mecanico modificado correctamente!");
        }else{
            JOptionPane.showMessageDialog(this, "No se pudo modificar el mecanico");
        }
        int id = mec.getIdMecanico();
        cargarMecanicos(dao.listar());
        seleccionarMecanico(id);
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        Mecanico mec = (Mecanico) jcbMecanico.getSelectedItem();
        if(mec == null){
            JOptionPane.showMessageDialog(this, "Seleccione un mecanico del combo");
            return;
        }
        int resp = JOptionPane.showConfirmDialog(this, "Desea eliminar a " + mec.getNombre() + "?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if(resp == JOptionPane.YES_OPTION){
            if(dao.eliminar(mec.getIdMecanico())){
                JOptionPane.showMessageDialog(this, "Mecanico eliminado");
                txtBuscar.setText("");
                cargarMecanicos(dao.listar());
                limpiarCampos();
            }else{
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el mecanico");
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FrmMecanico().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnVerTodos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<modelo.Mecanico> jcbMecanico;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblMecanico;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblOrden;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtOrden;
    // End of variables declaration//GEN-END:variables
}
