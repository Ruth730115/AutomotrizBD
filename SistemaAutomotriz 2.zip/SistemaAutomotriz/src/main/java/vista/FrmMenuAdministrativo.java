package vista;

/**
 * @author caria
 */
public class FrmMenuAdministrativo extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmMenuAdministrativo.class.getName());

    public FrmMenuAdministrativo() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Sistema Automotriz - Modulos Administrativos");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        btnClientes = new javax.swing.JButton();
        btnVehiculos = new javax.swing.JButton();
        btnMecanicos = new javax.swing.JButton();
        btnServicios = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnOrdenesdetrabajo = new javax.swing.JButton();
        btnPagos = new javax.swing.JButton();
        btnInventario = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(0, 153, 153));
        lblTitulo.setText("MODULOS ADMINISTRATIVOS");

        btnClientes.setBackground(new java.awt.Color(204, 255, 255));
        btnClientes.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClientes.setForeground(new java.awt.Color(0, 102, 102));
        btnClientes.setText("Clientes");
        btnClientes.addActionListener(this::btnClientesActionPerformed);

        btnVehiculos.setBackground(new java.awt.Color(204, 255, 255));
        btnVehiculos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnVehiculos.setForeground(new java.awt.Color(0, 102, 102));
        btnVehiculos.setText("Vehiculos");
        btnVehiculos.addActionListener(this::btnVehiculosActionPerformed);

        btnMecanicos.setBackground(new java.awt.Color(204, 255, 255));
        btnMecanicos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMecanicos.setForeground(new java.awt.Color(0, 102, 102));
        btnMecanicos.setText("Mecanicos");
        btnMecanicos.addActionListener(this::btnMecanicosActionPerformed);

        btnServicios.setBackground(new java.awt.Color(204, 255, 255));
        btnServicios.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnServicios.setForeground(new java.awt.Color(0, 102, 102));
        btnServicios.setText("Servicios");
        btnServicios.addActionListener(this::btnServiciosActionPerformed);

        btnSalir.setBackground(new java.awt.Color(204, 255, 255));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 102, 102));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(this::btnSalirActionPerformed);

        btnOrdenesdetrabajo.setBackground(new java.awt.Color(153, 153, 153));
        btnOrdenesdetrabajo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnOrdenesdetrabajo.setForeground(new java.awt.Color(0, 102, 102));
        btnOrdenesdetrabajo.setText("Ordenes de Trabajo");
        btnOrdenesdetrabajo.addActionListener(this::btnOrdenesdetrabajoActionPerformed);

        btnPagos.setBackground(new java.awt.Color(153, 153, 153));
        btnPagos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnPagos.setForeground(new java.awt.Color(0, 102, 102));
        btnPagos.setText("Pagos");
        btnPagos.addActionListener(this::btnPagosActionPerformed);

        btnInventario.setBackground(new java.awt.Color(153, 153, 153));
        btnInventario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnInventario.setForeground(new java.awt.Color(0, 102, 102));
        btnInventario.setText("Inventario");
        btnInventario.addActionListener(this::btnInventarioActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnInventario, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnOrdenesdetrabajo, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVehiculos, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMecanicos, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnServicios, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(lblTitulo))
                    .addComponent(btnPagos, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(171, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblTitulo)
                .addGap(34, 34, 34)
                .addComponent(btnClientes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVehiculos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnMecanicos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnServicios)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInventario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnOrdenesdetrabajo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnPagos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSalir)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
        FrmCliente frm = new FrmCliente();
        frm.setVisible(true);
    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnVehiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVehiculosActionPerformed
        FrmVehiculo frm = new FrmVehiculo();
        frm.setVisible(true);
    }//GEN-LAST:event_btnVehiculosActionPerformed

    private void btnMecanicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMecanicosActionPerformed
        FrmMecanico frm = new FrmMecanico();
        frm.setVisible(true);
    }//GEN-LAST:event_btnMecanicosActionPerformed

    private void btnServiciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnServiciosActionPerformed
        FrmServicio frm = new FrmServicio();
        frm.setVisible(true);
    }//GEN-LAST:event_btnServiciosActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnOrdenesdetrabajoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrdenesdetrabajoActionPerformed
        FrmOrdenTrabajo ventana = new FrmOrdenTrabajo();
    ventana.setLocationRelativeTo(null);
    ventana.setVisible(true);
    }//GEN-LAST:event_btnOrdenesdetrabajoActionPerformed

    private void btnPagosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPagosActionPerformed
      FrmPagos ventana = new FrmPagos();
    ventana.setLocationRelativeTo(null);
    ventana.setVisible(true);
    }//GEN-LAST:event_btnPagosActionPerformed

    private void btnInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventarioActionPerformed
        FrmInventario ventana = new FrmInventario();
    ventana.setLocationRelativeTo(null);
    ventana.setVisible(true);
    }//GEN-LAST:event_btnInventarioActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(() -> new FrmMenuAdministrativo().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClientes;
    private javax.swing.JButton btnInventario;
    private javax.swing.JButton btnMecanicos;
    private javax.swing.JButton btnOrdenesdetrabajo;
    private javax.swing.JButton btnPagos;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnServicios;
    private javax.swing.JButton btnVehiculos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblTitulo;
    // End of variables declaration//GEN-END:variables
}
