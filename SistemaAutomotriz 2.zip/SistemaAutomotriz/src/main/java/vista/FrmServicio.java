package vista;
import dao.ServicioDAO;
import modelo.Servicio;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * @author caria
 */
public class FrmServicio extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmServicio.class.getName());

    private ServicioDAO dao = new ServicioDAO();

    public FrmServicio() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Gestion de Servicios");

        cargarServicios(dao.listar());
        jcbNivel.setSelectedIndex(-1);
    }

    private void cargarServicios(ArrayList<Servicio> lista){
        try{
            jcbServicio.removeAllItems();

            for(Servicio ser : lista){
                jcbServicio.addItem(ser);
            }
            jcbServicio.setSelectedIndex(-1);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al cargar Servicios" + e.getMessage());
        }
    }

    private void seleccionarServicio(int idServicio){
        for(int i = 0; i < jcbServicio.getItemCount(); i++){
            if(jcbServicio.getItemAt(i).getIdServicio() == idServicio){
                jcbServicio.setSelectedIndex(i);
                break;
            }
        }
    }

    private void mostrarDatosEnCampos(Servicio ser){
        if(ser != null){
            txtCodigo.setText(ser.getCodigo());
            txtNombre.setText(ser.getNombre());
            txtDescripcion.setText(ser.getDescripcion());
            jcbNivel.setSelectedIndex(ser.getNivel() - 1);
            txtCosto.setText(String.valueOf(ser.getCostoManoObra()));
            txtTiempo.setText(String.valueOf(ser.getTiempoEstimado()));
        }else{
            limpiarCampos();
        }
    }

    private void limpiarCampos(){
        txtCodigo.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");
        jcbNivel.setSelectedIndex(-1);
        txtCosto.setText("");
        txtTiempo.setText("");
    }

    //validar
    private boolean validarCampos(){
        if(txtCodigo.getText().trim().equals("") || txtNombre.getText().trim().equals("")
                || txtDescripcion.getText().trim().equals("") || jcbNivel.getSelectedIndex() == -1
                || txtCosto.getText().trim().equals("") || txtTiempo.getText().trim().equals("")){
            JOptionPane.showMessageDialog(this, "Debe llenar todos los campos!!");
            return false;
        }
        if(txtCodigo.getText().trim().length() > 20 || txtNombre.getText().trim().length() > 100
                || txtDescripcion.getText().trim().length() > 200){
            JOptionPane.showMessageDialog(this, "El codigo admite maximo 20 caracteres, el nombre 100 y la descripcion 200");
            return false;
        }
        try{
            double costo = Double.parseDouble(txtCosto.getText().trim());
            if(costo < 0){
                JOptionPane.showMessageDialog(this, "El costo no puede ser negativo...");
                return false;
            }
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "El costo debe ser un numero...");
            return false;
        }
        try{
            double tiempo = Double.parseDouble(txtTiempo.getText().trim());
            if(tiempo <= 0){
                JOptionPane.showMessageDialog(this, "El tiempo estimado debe ser mayor que 0...");
                return false;
            }
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this, "El tiempo estimado debe ser un numero...");
            return false;
        }
        return true;
    }

    private void llenarServicio(Servicio ser){
        ser.setCodigo(txtCodigo.getText().trim().toUpperCase());
        ser.setNombre(txtNombre.getText().trim());
        ser.setDescripcion(txtDescripcion.getText().trim());
        ser.setNivel(jcbNivel.getSelectedIndex() + 1);
        ser.setCostoManoObra(Double.parseDouble(txtCosto.getText().trim()));
        ser.setTiempoEstimado(Double.parseDouble(txtTiempo.getText().trim()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnVerTodos = new javax.swing.JButton();
        lblServicio = new javax.swing.JLabel();
        jcbServicio = new javax.swing.JComboBox<>();
        lblCodigo = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblDescripcion = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        lblNivel = new javax.swing.JLabel();
        jcbNivel = new javax.swing.JComboBox<>();
        lblCosto = new javax.swing.JLabel();
        txtCosto = new javax.swing.JTextField();
        lblTiempo = new javax.swing.JLabel();
        txtTiempo = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnRegistrar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(0, 153, 153));
        lblTitulo.setText("GESTION DE SERVICIOS");

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(0, 153, 153));
        lblBuscar.setText("Buscar:");

        btnBuscar.setBackground(new java.awt.Color(204, 255, 255));
        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        btnVerTodos.setBackground(new java.awt.Color(204, 255, 255));
        btnVerTodos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnVerTodos.setForeground(new java.awt.Color(0, 102, 102));
        btnVerTodos.setText("Ver todos");
        btnVerTodos.addActionListener(this::btnVerTodosActionPerformed);

        lblServicio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblServicio.setForeground(new java.awt.Color(0, 153, 153));
        lblServicio.setText("Servicio:");

        jcbServicio.addActionListener(this::jcbServicioActionPerformed);

        lblCodigo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCodigo.setForeground(new java.awt.Color(0, 153, 153));
        lblCodigo.setText("Codigo:");

        lblNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNombre.setForeground(new java.awt.Color(0, 153, 153));
        lblNombre.setText("Nombre:");

        lblDescripcion.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblDescripcion.setForeground(new java.awt.Color(0, 153, 153));
        lblDescripcion.setText("Descripcion:");

        lblNivel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNivel.setForeground(new java.awt.Color(0, 153, 153));
        lblNivel.setText("Nivel:");

        jcbNivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 - Mantenimiento basico", "2 - Mantenimiento preventivo", "3 - Reparaciones intermedias", "4 - Reparaciones avanzadas", "5 - Reparaciones mayores" }));

        lblCosto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCosto.setForeground(new java.awt.Color(0, 153, 153));
        lblCosto.setText("Costo mano de obra:");

        lblTiempo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTiempo.setForeground(new java.awt.Color(0, 153, 153));
        lblTiempo.setText("Tiempo estimado (h):");

        btnNuevo.setBackground(new java.awt.Color(204, 255, 255));
        btnNuevo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 102, 102));
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(this::btnNuevoActionPerformed);

        btnRegistrar.setBackground(new java.awt.Color(204, 255, 255));
        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrar.setForeground(new java.awt.Color(0, 102, 102));
        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(this::btnRegistrarActionPerformed);

        btnModificar.setBackground(new java.awt.Color(204, 255, 255));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnModificar.setForeground(new java.awt.Color(0, 102, 102));
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(this::btnModificarActionPerformed);

        btnEliminar.setBackground(new java.awt.Color(204, 255, 255));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(0, 102, 102));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);

        btnSalir.setBackground(new java.awt.Color(204, 255, 255));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 102, 102));
        btnSalir.setText("Salir");
        btnSalir.addActionListener(this::btnSalirActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnVerTodos, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jcbServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblNivel, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jcbNivel, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(txtTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(lblTitulo)
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBuscar)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(btnVerTodos))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblServicio)
                    .addComponent(jcbServicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigo)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescripcion)
                    .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNivel)
                    .addComponent(jcbNivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCosto)
                    .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTiempo)
                    .addComponent(txtTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevo)
                    .addComponent(btnRegistrar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)
                    .addComponent(btnSalir))
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jcbServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbServicioActionPerformed
        Servicio serSeleccionado = (Servicio) jcbServicio.getSelectedItem();
        mostrarDatosEnCampos(serSeleccionado);
    }//GEN-LAST:event_jcbServicioActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String texto = txtBuscar.getText().trim();
        if(texto.equals("")){
            JOptionPane.showMessageDialog(this, "Escriba el codigo, nombre o descripcion a buscar");
            return;
        }
        ArrayList<Servicio> resultado = dao.buscar(texto);
        if(resultado.isEmpty()){
            JOptionPane.showMessageDialog(this, "No se encontraron servicios");
            return;
        }
        cargarServicios(resultado);
        jcbServicio.setSelectedIndex(0);
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnVerTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerTodosActionPerformed
  txtBuscar.setText("");
        cargarServicios(dao.listar());
    }//GEN-LAST:event_btnVerTodosActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        jcbServicio.setSelectedIndex(-1);
        limpiarCampos();
        txtCodigo.requestFocus();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        if(jcbServicio.getSelectedItem() != null){
            JOptionPane.showMessageDialog(this, "Presione 'Nuevo' para registrar un servicio nuevo o 'Modificar' para cambiar el seleccionado");
            return;
        }
        if(!validarCampos()){
            return;
        }
        Servicio ser = new Servicio();
        llenarServicio(ser);

        if(dao.existeCodigo(ser.getCodigo(), 0)){
            JOptionPane.showMessageDialog(this, "Ya existe un servicio con ese codigo");
            return;
        }
        if(dao.insertar(ser)){
            JOptionPane.showMessageDialog(this, "Servicio guardado correctamente!");
            txtBuscar.setText("");
            cargarServicios(dao.listar());
            limpiarCampos();
        }else{
            JOptionPane.showMessageDialog(this, "No se pudo guardar el servicio");
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        Servicio ser = (Servicio) jcbServicio.getSelectedItem();
        if(ser == null){
            JOptionPane.showMessageDialog(this, "Seleccione un servicio del combo");
            return;
        }
        if(!validarCampos()){
            return;
        }
        int id = ser.getIdServicio();
        llenarServicio(ser);

        if(dao.existeCodigo(ser.getCodigo(), id)){
            JOptionPane.showMessageDialog(this, "Ya existe otro servicio con ese codigo");
            return;
        }
        if(dao.modificar(ser)){
            JOptionPane.showMessageDialog(this, "Servicio modificado correctamente!");
        }else{
            JOptionPane.showMessageDialog(this, "No se pudo modificar el servicio");
        }
        cargarServicios(dao.listar());
        seleccionarServicio(id);
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        Servicio ser = (Servicio) jcbServicio.getSelectedItem();
        if(ser == null){
            JOptionPane.showMessageDialog(this, "Seleccione un servicio del combo");
            return;
        }
        int resp = JOptionPane.showConfirmDialog(this, "Desea eliminar el servicio " + ser.getNombre() + "?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if(resp == JOptionPane.YES_OPTION){
            if(dao.eliminar(ser.getIdServicio())){
                JOptionPane.showMessageDialog(this, "Servicio eliminado");
                txtBuscar.setText("");
                cargarServicios(dao.listar());
                limpiarCampos();
            }else{
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el servicio (puede estar usado en una orden)");
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new FrmServicio().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnVerTodos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> jcbNivel;
    private javax.swing.JComboBox<modelo.Servicio> jcbServicio;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblCosto;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblNivel;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblServicio;
    private javax.swing.JLabel lblTiempo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTiempo;
    // End of variables declaration//GEN-END:variables
}
