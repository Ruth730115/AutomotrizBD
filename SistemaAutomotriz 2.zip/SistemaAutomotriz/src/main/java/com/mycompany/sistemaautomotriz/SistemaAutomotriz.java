package com.mycompany.sistemaautomotriz;

import vista.FrmMenuAdministrativo;

/**
 * Clase principal. Abre el menu de los modulos administrativos (Integrante 2).
 */
public class SistemaAutomotriz {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new FrmMenuAdministrativo().setVisible(true));
    }
}
